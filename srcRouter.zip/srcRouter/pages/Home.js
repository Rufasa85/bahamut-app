import React from 'react'

export default function Home() {
    return (
        <div>
            <h1>Home page is here!</h1>
            <h2>Check it out!</h2>
        </div>
    )
}
